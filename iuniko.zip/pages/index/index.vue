<template>
	<view class="warper">
		<view class="header">
			<view class="left">
				iuniko
			</view>
			<view class="nav">
				<view class="navItem" v-for="(item,index) in navData" :key="item">
					<view>{{item.name}}</view>
				</view>
			</view>
			<view class="right">
				<u-search bg-color="#fff" placeholder="日照香炉生紫烟" v-model="keyword"></u-search>
			</view>
		</view>
		<view class="swBox">
			<u-swiper :list="list" height="640"></u-swiper>
		</view>

		<view class="content">
			<view class="leftSide">
				<view class="leftSideBox" v-for="(item,index) in navData2" :key="index">
					<view class="leftSideBoxItem">
						<image class="leftSideBoxItemImg" :src="item.src" mode=""></image>
						<view class="title">
							{{item.title}}
						</view>
						<view class="desciprtion">
							{{item.desciprtion}}
						</view>
						<view class="line"></view>
						<view class="foot">
							<view class="date">
								<u-icon name="calendar"></u-icon>
								02-09
							</view>
							<view class="view">
								<u-icon name="eye"></u-icon>
								5720
							</view>
							<view class="comment">
								<u-icon name="more-circle"></u-icon>
								0
							</view>
						</view>
					</view>
				</view>
			</view>
			<view class="rightSide">
				<view class="introduction">
					<view class="top">
						<image class="img" src="http://skk-0413-6.demo.mxyhn.xyz/ECMS_DGZJ/img/DGZJ.jpg" mode="">
						</image>
						<h1>iuniko</h1>
						<p>这是一段很长很长很长很长很长很长很长很长很长很长很长很长很长很长很长很长很长很长的描述</p>
					</view>
					<view class="box">
						<h1>165</h1>
						<p>文章数</p>
					</view>
					<view class="box">
						<h1>857857</h1>
						<p>阅读数</p>
					</view>
					<view class="box">
						<h1>1亿+</h1>
						<p>评论数</p>
					</view>
				</view>
				<view class="hotspot">
					<h1>热点</h1>
					<view class="box" v-for="(item,index) in navData3" :key="index">
						<image class="img" :src="item.src" mode=""></image>
						<view class="u-line-2 title">
							{{item.title}}
						</view>
					</view>
				</view>
				<view class="tab">
					<h1>标签列表</h1>
					<view class="box" v-for="(item,index) in navData4" :key="index">
						{{item}}
					</view>
				</view>
				<view class="link">
					<h1>友情链接</h1>
					<view class="box" v-for="(item,index) in navData5" :key="index">
						{{item}}
					</view>
				</view>
			</view>
		</view>
		
		<view class="foot">
			Copyright © 2021 iuniko
		</view>
		
	</view>
</template>

<script>
	export default {
		data() {
			return {
				navtitle: '首页',
				keyword: '遥看瀑布挂前川',
				navData: [{
						name: "首页",
					},
					{
						name: "动态",
					},
					{
						name: "我的",
					},
				],

				navData2: [{
						desciprtion: "啊就是1",
						src: "http://skk-0413-6.demo.mxyhn.xyz/e/data/images/notimg.gif",
						title: "发布一篇没有图片的文章，没有图片则显示默认文章图片！",
					},
					{
						desciprtion: "就是2",
						src: "http://skk-0413-6.demo.mxyhn.xyz/e/data/images/notimg.gif",
						title: "发布一篇没有图片的文章，没有图片则显示默认文章图片！",
					},
					{
						desciprtion: "啊是就是3",
						src: "http://skk-0413-6.demo.mxyhn.xyz/e/data/images/notimg.gif",
						title: "发布一篇没有图片的文章，没有图片则显示默认文章图片！",
					},
					{
						desciprtion: "啊是就是3",
						src: "http://skk-0413-6.demo.mxyhn.xyz/e/data/images/notimg.gif",
						title: "发布一篇没有图片的文章，没有图片则显示默认文章图片！",
					},
					{
						desciprtion: "啊是就是3",
						src: "http://skk-0413-6.demo.mxyhn.xyz/e/data/images/notimg.gif",
						title: "发布一篇没有图片的文章，没有图片则显示默认文章图片！",
					},
					{
						desciprtion: "啊是就是3",
						src: "http://skk-0413-6.demo.mxyhn.xyz/e/data/images/notimg.gif",
						title: "发布一篇没有图片的文章，没有图片则显示默认文章图片！",
					},
					{
						desciprtion: "啊是就是3",
						src: "http://skk-0413-6.demo.mxyhn.xyz/e/data/images/notimg.gif",
						title: "发布一篇没有图片的文章，没有图片则显示默认文章图片！",
					},
					{
						desciprtion: "啊是就是3",
						src: "http://skk-0413-6.demo.mxyhn.xyz/e/data/images/notimg.gif",
						title: "发布一篇没有图片的文章，没有图片则显示默认文章图片！",
					},
					{
						desciprtion: "啊是就是3",
						src: "http://skk-0413-6.demo.mxyhn.xyz/e/data/images/notimg.gif",
						title: "发布一篇没有图片的文章，没有图片则显示默认文章图片！",
					},
					{
						desciprtion: "啊是就是3",
						src: "http://skk-0413-6.demo.mxyhn.xyz/e/data/images/notimg.gif",
						title: "发布一篇没有图片的文章，没有图片则显示默认文章图片！",
					},
					{
						desciprtion: "啊是就是3",
						src: "http://skk-0413-6.demo.mxyhn.xyz/e/data/images/notimg.gif",
						title: "发布一篇没有图片的文章，没有图片则显示默认文章图片！",
					},
					{
						desciprtion: "啊是就是3",
						src: "http://skk-0413-6.demo.mxyhn.xyz/e/data/images/notimg.gif",
						title: "发布一篇没有图片的文章，没有图片则显示默认文章图片！",
					},
					{
						desciprtion: "啊是就是3",
						src: "http://skk-0413-6.demo.mxyhn.xyz/e/data/images/notimg.gif",
						title: "发布一篇没有图片的文章，没有图片则显示默认文章图片！",
					},
					{
						desciprtion: "啊是就是3",
						src: "http://skk-0413-6.demo.mxyhn.xyz/e/data/images/notimg.gif",
						title: "发布一篇没有图片的文章，没有图片则显示默认文章图片！",
					},
					{
						desciprtion: "啊是就是3",
						src: "http://skk-0413-6.demo.mxyhn.xyz/e/data/images/notimg.gif",
						title: "发布一篇没有图片的文章，没有图片则显示默认文章图片！",
					},
					{
						desciprtion: "啊是就是3",
						src: "http://skk-0413-6.demo.mxyhn.xyz/e/data/images/notimg.gif",
						title: "发布一篇没有图片的文章，没有图片则显示默认文章图片！",
					},
					{
						desciprtion: "啊是就是3",
						src: "http://skk-0413-6.demo.mxyhn.xyz/e/data/images/notimg.gif",
						title: "发布一篇没有图片的文章，没有图片则显示默认文章图片！",
					},
					{
						desciprtion: "啊是就是3",
						src: "http://skk-0413-6.demo.mxyhn.xyz/e/data/images/notimg.gif",
						title: "发布一篇没有图片的文章，没有图片则显示默认文章图片！",
					},
				],

				navData3: [{
						title: '前鸳鸯锦十大hi时间吗，12萨芬核功能接口口打赏法华经是多么',
						src: 'http://skk-0413-6.demo.mxyhn.xyz/d/file/p/2020/02-09/70b78ee5707a2b804a3af10e7398c00a.jpg',
					},
					{
						title: '前鸳鸯锦十大hi时间吗，12萨芬核功能接口口打赏法华经是多么',
						src: 'http://skk-0413-6.demo.mxyhn.xyz/d/file/p/2020/02-09/70b78ee5707a2b804a3af10e7398c00a.jpg',
					},
					{
						title: '前鸳鸯锦十大hi时间吗，12萨芬核功能接口口打赏法华经是多么',
						src: 'http://skk-0413-6.demo.mxyhn.xyz/d/file/p/2020/02-09/70b78ee5707a2b804a3af10e7398c00a.jpg',
					},
					{
						title: '前鸳鸯锦十大hi时间吗，12萨芬核功能接口口打赏法华经是多么',
						src: 'http://skk-0413-6.demo.mxyhn.xyz/d/file/p/2020/02-09/70b78ee5707a2b804a3af10e7398c00a.jpg',
					},
					{
						title: '前鸳鸯锦十大hi时间吗，12萨芬核功能接口口打赏法华经是多么',
						src: 'http://skk-0413-6.demo.mxyhn.xyz/d/file/p/2020/02-09/70b78ee5707a2b804a3af10e7398c00a.jpg',
					},
					{
						title: '前鸳鸯锦十大hi时间吗，12萨芬核功能接口口打赏法华经是多么',
						src: 'http://skk-0413-6.demo.mxyhn.xyz/d/file/p/2020/02-09/70b78ee5707a2b804a3af10e7398c00a.jpg',
					},
					{
						title: '前鸳鸯锦十大hi时间吗，12萨芬核功能接口口打赏法华经是多么',
						src: 'http://skk-0413-6.demo.mxyhn.xyz/d/file/p/2020/02-09/70b78ee5707a2b804a3af10e7398c00a.jpg',
					},
					{
						title: '前鸳鸯锦十大hi时间吗，12萨芬核功能接口口打赏法华经是多么',
						src: 'http://skk-0413-6.demo.mxyhn.xyz/d/file/p/2020/02-09/70b78ee5707a2b804a3af10e7398c00a.jpg',
					},
				],

				navData4: [
					"网红",
					"互联网",
					"创业",
					"快手",
					"股票",
					"养殖",
					"网红",
					"互联网",
					"创业",
					"快手",
					"股票",
					"养殖",
				],

				navData5: [
					"的十大进球位居犯得上看见开的发你哭什么",
					"当时的看看什么过分了多少免费观看就",
					"dfjn十大科技什么的拉萨，分类",
					"dasd",
					"含快递费孤苦伶仃的访客管理人来听课老师，大量非法，拉萨扩大了，二零",
					"的撒回复你jam贷款门槛萨达姆卡上面的客户士大夫",					
				],

				list: [{
						image: 'http://skk-0413-6.demo.mxyhn.xyz/ECMS_DGZJ/img/banner1.jpg',
						title: 'xxx',
					},
					{
						image: 'http://skk-0413-6.demo.mxyhn.xyz/ECMS_DGZJ/img/banner2.jpg',
						title: 'yyy',
					},
					{
						image: 'http://skk-0413-6.demo.mxyhn.xyz/ECMS_DGZJ/img/banner2.jpg',
						title: 'zzz',
					},
				],

			}
		},
		onLoad() {

		},
		methods: {

		}
	}
</script>

<style scoped lang="scss">
	page {
		background-color: #f2f2f2;
	}

	.lin {
		width: 2rpx;
		background-color: #ccc;
	}

	.warper {
		width: 2280rpx;
		margin: 0 auto;
		overflow: hidden;

		.header {
			width: 100%;
			height: 120rpx;
			line-height: 120rpx;
			overflow: hidden;

			.left {
				width: 100px;
				float: left;
			}

			.nav {
				width: calc(100% - 350px);
				float: left;
				overflow: hidden;

				.navItem {
					float: left;
					margin-right: 40rpx;
				}
			}

			.right {
				width: 250px;
				float: right;
				
			}
		}

		.swBox {}

		.content {
			overflow: hidden;

			.leftSide {
				width: 1600rpx;
				float: left;
				overflow: hidden;

				.leftSideBox {
					width: 500rpx;
					margin-right: 32rpx;
					margin-top: 32rpx;
					float: left;

					.leftSideBoxItem {
						background-color: #fff;
						padding: 40rpx;

						.leftSideBoxItemImg {
							width: 100%;
							height: 296rpx;
						}

						.title {
							font-weight: normal;
							margin-top: 4rpx;
						}

						.desciprtion {
							font-size: 28rpx;
							color: #ccc;
							margin-top: 4rpx;
						}

						.line {
							width: 100%;
							height: 2rpx;
							margin-top: 20rpx;
							background-color: #f2f2f2;
						}

						.foot {
							margin-top: 20rpx;
							overflow: hidden;

							.date {
								float: left;
								width: 50%;
							}

							.view {
								float: left;
								width: 25%;
							}

							.comment {
								float: left;
								width: 25%;
							}
						}
					}

				}
			}

			.rightSide {
				width: 680rpx;
				float: left;
				margin-top: 32rpx;

				.introduction {
					background-color: #fff;
					margin-bottom: 32rpx;
					text-align: center;
					overflow: hidden;

					.top {
						.img {
							width: 120rpx;
							height: 120rpx;
							margin-top: 40rpx;
						}

						p {
							padding: 32rpx;
						}

					}

					.box {
						width: 33%;
						float: left;
						border-right: 1px solid #ccc;
						margin-top: 32rpx;
						margin-bottom: 32rpx;
						padding: 10rpx;

						h1 {
							font-weight: 600;
							font-size: 36rpx;
						}

						p {
							margin-top: 10rpx;
							color: #c0c0c0;
						}
					}

					.box:last-child {
						border: none;
					}

				}

				.hotspot {
					background-color: #fff;
					margin-bottom: 32rpx;
					overflow: hidden;

					h1 {
						font-size: 32rpx;
						font-weight: 600;
						padding-top: 20rpx;
						padding-left: 20rpx;
					}

					.box {
						width: 340rpx;
						float: left;
						padding: 20rpx;

						.img {
							width: 100%;
							height: 200rpx;
							border-radius: 8rpx;
						}

					}
				}

				.tab {
					background-color: #fff;
					margin-bottom: 32rpx;
					overflow: hidden;
					padding-bottom: 20rpx;

					h1 {
						font-size: 32rpx;
						font-weight: 600;
						padding-top: 20rpx;
						padding-left: 20rpx;
					}

					.box {
						border: 1px dashed #ccc;
						padding: 8rpx;
						border-radius: 16rpx;
						float: left;
						margin-left: 20rpx;
						margin-top: 20rpx;
					}

				}

				.link {
					background-color: #fff;

					h1 {
						font-size: 32rpx;
						font-weight: 600;
						padding-top: 20rpx;
						padding-left: 20rpx;
					}
					
					.box {
						padding: 20rpx;
					}
				}

			}

		}

		.foot {
			text-align: center;
			background-color: #fff;
			margin: 32rpx auto 0;
			padding: 20rpx;
		}
		
	}
</style>
